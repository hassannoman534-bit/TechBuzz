import type { Metadata } from "next";
import { PortfolioHero } from "@/components/sections/portfolio-hero/portfolio-hero";
import { WorkList } from "@/components/sections/work-list/work-list";
import { FolioShowcase } from "@/components/sections/folio-showcase/folio-showcase";
import { ClientWall } from "@/components/sections/client-wall/client-wall";
import { SiteFooter } from "@/components/sections/site-footer/site-footer";

export const metadata: Metadata = {
  title: "Portfolio | TechBuzz",
  description: "Selected brand, social, web and app work by TechBuzz, a digital agency in Lahore.",
};

export default function PortfolioPage() {
  return (
    <main className="bg-[#030712]">
      <PortfolioHero />
      <WorkList hideHeading />
      <FolioShowcase />
      <ClientWall />
      <SiteFooter />
    </main>
  );
}
