"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useReducedMotionSafe } from "@/lib/use-reduced-motion-safe";

export type PortfolioHeroContent = {
  eyebrow: string;
  /** 2 to 3 bold words */
  heading: string;
  /** One short line under the heading */
  intro: string;
};

export const portfolioHero: PortfolioHeroContent = {
  eyebrow: "Portfolio",
  heading: "Work That Talks.",
  intro: "Brands we have helped people notice, remember and talk about.",
};

type PortfolioHeroProps = { content?: PortfolioHeroContent; className?: string };

const EASE = [0.22, 1, 0.36, 1] as const;

/**
 * Simple portfolio opening: a soft glow, a centred bold heading and one line of copy.
 * One gentle entrance on load (words rise, then the line fades in). No pinning, no scroll effects.
 */
export function PortfolioHero({ content = portfolioHero, className }: PortfolioHeroProps) {
  const reduce = useReducedMotionSafe();
  const words = content.heading.split(" ");

  return (
    <section
      aria-labelledby="portfolio-hero-heading"
      className={cn("relative flex min-h-[78svh] flex-col items-center justify-center overflow-hidden bg-[#030712] px-5 pb-16 pt-32 text-center text-white", className)}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-[radial-gradient(55%_45%_at_50%_45%,rgb(123_97_255/0.12),transparent_70%)]" />
      {/* soft fade into the next section, no hard edge */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-b from-transparent to-[#030712]" />

      <motion.p
        initial={reduce ? false : { opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: EASE }}
        className="relative text-[0.72rem] font-medium uppercase tracking-[0.22em] text-white/50"
      >
        ( {content.eyebrow} )
      </motion.p>

      <h1
        id="portfolio-hero-heading"
        className="relative mt-5 font-footer-display text-[clamp(3rem,10vw,10rem)] font-bold leading-[0.92] tracking-[-0.05em]"
      >
        {words.map((word, i) => (
          <span key={`${word}-${i}`} className="inline-block overflow-hidden pb-[0.08em] align-bottom">
            <motion.span
              className="inline-block"
              initial={reduce ? false : { y: "105%" }}
              animate={{ y: "0%" }}
              transition={{ duration: 1, ease: EASE, delay: 0.1 + i * 0.08 }}
            >
              {word}
              {i < words.length - 1 ? " " : ""}
            </motion.span>
          </span>
        ))}
      </h1>

      <motion.p
        initial={reduce ? false : { opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 0.45 }}
        className="relative mt-6 max-w-[34rem] text-[clamp(1rem,1.3vw,1.15rem)] leading-relaxed text-white/60"
      >
        {content.intro}
      </motion.p>
    </section>
  );
}
