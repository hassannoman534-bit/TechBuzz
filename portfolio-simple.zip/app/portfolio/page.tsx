import type { Metadata } from "next";
import { PortfolioHero } from "@/components/sections/portfolio-hero/portfolio-hero";
import { WorkList } from "@/components/sections/work-list/work-list";

export const metadata: Metadata = {
  title: "Portfolio | TechBuzz",
  description: "Selected brand, social, web and app work by TechBuzz, a digital agency in Lahore.",
};

export default function PortfolioPage() {
  return (
    <main className="bg-[#030712]">
      <PortfolioHero />
      <WorkList hideHeading />
    </main>
  );
}
